function saveShayari() {
    alert("Shayari Saved ❤️");
}

function commentShayari() {
    document.getElementById("commentBox").style.display = "block";
}

function postComment() {
    let comment = document.getElementById("userComment").value;

    if (comment.trim() === "") {
        alert("Please write a comment!");
        return;
    }

    let p = document.createElement("p");
    p.innerText = comment;

    document.getElementById("comments").appendChild(p);

    document.getElementById("userComment").value = "";
}